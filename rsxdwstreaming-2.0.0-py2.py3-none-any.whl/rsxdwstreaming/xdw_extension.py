import bitstring

# pylint: disable=too-few-public-methods


class PdwParamsStuffing:
    """Class for stuffing PDW params
    """
    def __init__(self):
        self.param = bitstring.BitArray(32)


class PdwParamsEdge:
    """Class for basic edge shaping PDW params

    :param edge_type: Define edge type, 0 = linear, 1 = raised cosine
    :type edge_type: int
    :param multiplier: multiplication factor for rise_fall_time, 0 = x1, 1 = x8
    :type multiplier: int
    :param rise_fall_time: common rise and fall time in seconds
    :type rise_fall_time: float

    """
    def __init__(self, edge_type, multiplier, rise_fall_time):
        self.param = bitstring.pack('uint:3, uint:1, uint:6, uint:22', edge_type, multiplier, 0,
                                    rise_fall_time * 2.4e9)


class XdwExtensionUnused:
    """Class for unused PDW extensions
    """
    def __init__(self):
        self.type = 0
        self.extension = bitstring.BitArray(48)


class XdwExtensionEdge:
    """Class for edge shaping PDW extension

    :param edge_type: Define edge type, 0 = linear, 1 = raised cosine
    :type edge_type: int
    :param multiplier: multiplication factor for rise_fall_time, 0 = x1, 1 = x8
    :type multiplier: int
    :param rise_time: rise time in seconds
    :type rise_time: float
    :param fall_time: fall time in seconds
    :type fall_time: float

    """
    def __init__(self, edge_type, multiplier, rise_time, fall_time):
        self.type = 1
        self.extension = bitstring.pack('uint:3, uint:1, uint:22, uint:22', edge_type, multiplier,
                                        rise_time * 2.4e9, fall_time * 2.4e9)


class XdwExtensionBurst:
    """Class for burst PDW extension

    :param pri: pulse repetition interval in seconds
    :type pri: float
    :param add_pulses: additional pulses
    :type add_pulses: int

    """
    def __init__(self, pri, add_pulses):
        self.type = 2
        self.extension = bitstring.pack('uint:32, uint:16', pri * 2.4e9, add_pulses)
