from enum import Enum


class XdwFormat(Enum):
    """Enums to determine xDW Format
    """
    PDW_BASIC = 1
    PDW_EXPERT = 2
    ADW_BASIC = 3
