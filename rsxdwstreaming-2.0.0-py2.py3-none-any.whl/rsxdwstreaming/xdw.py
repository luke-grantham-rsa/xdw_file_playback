from abc import ABC, abstractmethod

import bitstring
from . import xdw_payload


class Xdw(ABC):
    # pylint: disable=too-many-instance-attributes
    """Base class for R&S descriptor words. Only to be used via classes Adw, PdwBasic or PdwExpert.
    """
    def __init__(self, xdw_format, payload, **kwargs):
        self.toa = 0
        self.seg = 0    # no need to modify this, it is set by payload later

        self.phase_mod = 0
        self.ignore_xdw = 0
        self.m3 = 0
        self.m2 = 0
        self.m1 = 0

        self.freq_offset = 0
        self.level_offset = 0
        self.phase_offset = 0

        # all variables below shall be treated as private
        self.xdw_format = xdw_format

        self.payload = payload

        self.b_xdw_header = b''
        self.b_xdw_flags = b''
        self.b_xdw_body = b''
        self.b_xdw_payload = b''

        allowed_keys = {'toa', 'phase_mod', 'ignore_xdw', 'm3', 'm2', 'm1', 'freq_offset', 'level_offset', 'phase_offset'}
        for k, _ in kwargs.items():
            if k not in allowed_keys:
                assert False, f'{k} is not in {allowed_keys}'

        self.__dict__.update((k, v) for k, v in kwargs.items() if k in allowed_keys)

    @abstractmethod
    def create_xdw_header(self):
        """Abstract method: assemble xDW header and write to member variable
        """

    def create_xdw_flags(self):
        """Assemble xDW flags and write to member variable
        """
        bs_packed = bitstring.pack('uint:1, uint:1, uint:1, uint:1, uint:1, uint:1, uint:1, uint:1',
                                   0,  # is not a ctrl xdw
                                   0,  # rsvd (former rtdata)
                                   self.phase_mod,
                                   self.ignore_xdw,
                                   0,  # m4 is reserved
                                   self.m3, self.m2, self.m1)
        self.b_xdw_flags = bs_packed.bytes

    def create_xdw_body(self):
        """Assemble xDW body and write to member variable
        """
        assert self.level_offset >= 0, "Only attenuation is supported by LEV."

        i_frq = (int(self.freq_offset * 2 ** 48 / 2.4e9)) >> 16  # generate PDW body FRQ
        i_lev = round(10 ** (-self.level_offset / 20) * (2 ** 15))  # generate PDW body LEV
        i_phs = round((self.phase_offset / 360) * (2 ** 16))  # generate PDW body PHS

        bs_packed = bitstring.pack('int:32, uint:16, uint:16', i_frq, i_lev, i_phs)
        self.b_xdw_body = bs_packed.bytes

    def create_xdw_payload(self):
        """Assemble xDW payload and write to member variable
        """
        self.seg = 0
        self.b_xdw_payload = self.payload.get_payload(self.xdw_format)

        if self.payload.__class__ is xdw_payload.XdwPayloadSegmentArb:
            self.seg = 1

    @abstractmethod
    def get_xdw(self):
        """Abstract method: Assemble xDW
        """
