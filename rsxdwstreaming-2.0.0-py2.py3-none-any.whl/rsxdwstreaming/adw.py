# pylint: skip-file
import bitstring

from rsxdwstreaming.xdw import Xdw
from rsxdwstreaming.xdw_extension import PdwParamsStuffing, XdwExtensionUnused
from .xdw_format import XdwFormat


class Adw(Xdw):
    r"""ARB descriptor word (ADW) class

    :param payload: ADW payload
    :param seg_interrupt: Flag to determine if segment can be interrupted, defaults to False
    :type seg_interrupt: bool
    :param extension: ADW extension, supported: XdwExtensionUnused, XdwExtensionBurst, defaults to XdwExtensionUnused
    :keyword ignore_xdw: Flag to determine if ADW is ignored
    :type ignore_xdw: bool
    :keyword m1: Marker 1
    :keyword m2: Marker 2
    :keyword m3: Marker 3
    :keyword freq_offset: Frequency offset in Hertz
    :keyword level_offset: Level offset in dB
    :keyword phase_offset: Phase offset in degree

    """
    def __init__(self, payload, seg_interrupt=0,
                 extension=XdwExtensionUnused(),
                 **kwargs):
        # pylint: disable=too-many-arguments
        kwargs['toa'] = 0
        super().__init__(xdw_format=XdwFormat.ADW_BASIC, payload=payload, **kwargs)

        self.use_extension = 0
        self.params = 0

        self.param = PdwParamsStuffing()
        self.extensions = [extension, XdwExtensionUnused(), XdwExtensionUnused()]
        self.seg_interrupt = seg_interrupt

    def create_xdw_header(self):
        """Assemble ADW header and write to member variable
        """
        toa_ticks = round(self.toa * 2.4e9)

        bs_packed = bitstring.pack('uint:52, uint:1, uint:1, uint:2',
                                   toa_ticks, self.seg, self.use_extension, self.params)
        self.b_xdw_header = bs_packed.bytes

    def create_xdw_flags(self):
        """Assemble ADW flags and write to member variable
        """
        # generate PDW flags
        bs_packed = bitstring.pack('uint:1, uint:1, uint:1, uint:1, uint:1, uint:1, uint:1, uint:1',
                                   0,  # is not a ctrl xdw
                                   self.seg_interrupt,
                                   0,  # phase_mod not supported,
                                   self.ignore_xdw,
                                   0,  # m4 is reserved
                                   self.m3, self.m2, self.m1)
        self.b_xdw_flags = bs_packed.bytes

    def create_xdw_extension(self):
        """Assemble ADW extension and return bytes object

        :return: Raw ADW extension
        :rtype: Bytes Object

        """
        bs_packed = bitstring.pack('bits:48', self.extensions[0].extension)
        return bs_packed.bytes

    def get_xdw(self):
        """Assemble ADW from header, flags, body, payload and extension

        :return: Raw ADW
        :rtype: Bytes Object

        """
        self.create_xdw_payload()  # create payload first as this function sets data used by flags and header
        self.create_xdw_flags()
        self.create_xdw_body()

        # check if an extension is defined
        for extension in self.extensions:
            if extension.__class__ is not XdwExtensionUnused:
                self.use_extension = 1

        self.create_xdw_header()  # create header at last because seg, ext and param information is set not set before

        ret = self.b_xdw_header + self.b_xdw_flags + self.b_xdw_body + self.b_xdw_payload + self.create_xdw_extension()
        return ret
