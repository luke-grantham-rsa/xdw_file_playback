import bitstring
from .xdw import Xdw
from .xdw_format import XdwFormat


class PdwBasic(Xdw):
    r"""Basic pulse descriptor word (PDW) class

    :param payload: PDW payload
    :keyword toa: time-of-arrival (toa) describes the time of playback relative to simulation start
    :keyword ignore_xdw: Flag to determine if PDW is ignored
    :keyword phase_mod: Flag to set phase mode to absolute (=0) or relative (=1)
    :keyword m1: Marker 1
    :keyword m2: Marker 2
    :keyword m3: Marker 3
    :keyword freq_offset: Frequency offset in Hertz
    :keyword level_offset: Level offset in dB
    :keyword phase_offset: Phase offset in degree

    """
    def __init__(self, payload, **kwargs):
        super().__init__(xdw_format=XdwFormat.PDW_BASIC, payload=payload, **kwargs)

    def create_xdw_header(self):
        """Assemble basic PDW header and write to member variable
        """
        toa_ticks = round(self.toa * 2.4e9)

        bs_packed = bitstring.pack('uint:44, uint:1, uint:3',
                                   toa_ticks, self.seg, 0)
        self.b_xdw_header = bs_packed.bytes

    def get_xdw(self):
        """Assemble basic PDW from header, flags, body and payload

        :return: Raw basic PDW
        :rtype: Bytes Object

        """
        self.create_xdw_payload()  # create payload first as this function sets data used by flags and header

        self.create_xdw_header()
        self.create_xdw_flags()
        self.create_xdw_body()

        return self.b_xdw_header + self.b_xdw_flags + self.b_xdw_body + self.b_xdw_payload
