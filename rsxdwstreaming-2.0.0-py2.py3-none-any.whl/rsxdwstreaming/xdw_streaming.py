import socket
import os


class XdwStreaming:
    """Initialize the xDW streaming interface to be able to stream xDW data to generator.

    :param if_ip_addr: IP address of generator interface, e.g. '127.0.0.1'
    :type if_ip_addr: str
    :param port: network port, defaults to 49152
    :type port: int
    :param protocol: desired protocol, either TCP or UDP, defaults to 'TCP'
    :type protocol: str
    :param options: see socket.setsockopt for more information

    """
    def __init__(self, if_ip_addr: str, port: int = 49152, protocol: str = 'TCP', options=()):
        if_ip_addr = if_ip_addr.replace('"', '')
        if_ip_addr = if_ip_addr.rstrip()

        protocol = protocol.strip()
        protocol = protocol.upper()

        if protocol == 'TCP':
            soc_type = socket.SOCK_STREAM
        elif protocol == 'UDP':
            soc_type = socket.SOCK_DGRAM
        else:
            raise RuntimeError(f'unsupported protocol: {protocol}')

        self.xdw_interface = socket.socket(socket.AF_INET, soc_type)

        # option = (protocol, option, value)
        if options:
            self.xdw_interface.setsockopt(*options)

        self.xdw_interface.connect((if_ip_addr, port))

    def __del__(self):
        self.xdw_interface.shutdown(socket.SHUT_RDWR)
        self.xdw_interface.close()

    def send_xdw(self, data):
        """Sends a bytes object to the xDW streaming interface

        :param data: raw xDW bytes
        :type data: bytes object

        """
        totalsent = 0
        while totalsent < data.__len__():
            sent = self.xdw_interface.send(data[totalsent:])
            if sent == 0:
                raise RuntimeError("socket connection broken")
            totalsent = totalsent + sent

    @staticmethod
    def write_file(filename, pdw_list):
        """Writes a list of xDW objects to a binary file

        :param filename: filename of destination file
        :type filename: str
        :param pdw_list: List of xDWs
        :type pdw_list: list

        """
        b_xdw_raw = bytearray()
        for xdw in pdw_list:
            b_xdw_raw += xdw.get_xdw()

        filename_int = os.path.normpath(filename)

        with open(filename_int, 'wb') as f:
            f.write(bytes(b_xdw_raw))

    def stream_file(self, filename):
        """Streams the content of a binary xDW file to the xDW streaming interface

        :param filename: filename of source file
        :type filename: str

        """
        filename_int = os.path.normpath(filename)

        with open(filename_int, 'rb') as f:
            self.send_xdw(f.read())
