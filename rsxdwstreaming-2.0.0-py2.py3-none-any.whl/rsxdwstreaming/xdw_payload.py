
from dataclasses import dataclass

import bitstring
from .xdw_format import XdwFormat


@dataclass
class XdwPayloadSegmentArb:
    """Payload class to address pre-calculated ARB segments

    :param segment_idx: list index of addressed segment
    :type segment_idx: int

    """
    segment_idx: int

    def get_payload(self, xdw_format: XdwFormat):
        """Assemble payload and return bytes object

        :param xdw_format: Type of xDW, e.g. PDW_BASIC
        :type xdw_format: XdwFormat
        :return: Raw payload
        :rtype: Bytes Object

        """
        assert self.segment_idx >= 0
        assert self.segment_idx <= 16777215, "Maximum value for segment index is 16777215."
        b_segment_index = self.segment_idx.to_bytes(3, byteorder="big")

        if xdw_format == XdwFormat.PDW_BASIC:
            rsvd_bytes = 14
        elif xdw_format == XdwFormat.PDW_EXPERT:
            rsvd_bytes = 9
        else:  # ADW_BASIC
            rsvd_bytes = 7

        b_pdw_payload = b_segment_index + bytes(rsvd_bytes)
        return b_pdw_payload


@dataclass
class PdwPayloadRtUnmod:
    """Payload class to generate unmodulated real-time pulse

    :param t_on: duration of pulse (on-time)
    :type t_on: float

    """
    t_on: float

    def get_payload(self, xdw_format: XdwFormat):
        """Assemble payload and return bytes object

        :param xdw_format: Type of xDW, e.g. PDW_BASIC
        :type xdw_format: XdwFormat
        :return: Raw payload
        :rtype: Bytes Object

        """
        t_on_ticks = int(self.t_on * 2.4e9)

        assert t_on_ticks < (2 ** 44), "t_on in ticks exceeds 44 bits"

        if xdw_format == XdwFormat.PDW_BASIC:
            rsvd_bytes = 11
        elif xdw_format == XdwFormat.PDW_EXPERT:
            rsvd_bytes = 6
        else:
            raise ValueError('unsupported xdw format')

        b_pdw_payload = t_on_ticks.to_bytes(6, byteorder="big") + bytes(rsvd_bytes)
        return b_pdw_payload


@dataclass
class PdwPayloadRtChirpLinear:
    """Payload class to generate linear frequency modulated real-time pulse

    :param t_on: duration of pulse (on-time)
    :type t_on: float
    :param freq_step: frequency step per sample
    :type freq_step: float

    """
    t_on: float
    freq_step: float

    def get_payload(self, xdw_format: XdwFormat):
        """Assemble payload and return bytes object

        :param xdw_format: Type of xDW, e.g. PDW_BASIC
        :type xdw_format: XdwFormat
        :return: Raw payload
        :rtype: Bytes Object

        """
        t_on_ticks = int(self.t_on * 2.4e9)
        i_freq_inc = int(self.freq_step / 2.4e9 * (2 ** 64))

        assert t_on_ticks < (2 ** 25), "t_on in ticks exceeds 25 bits"

        if xdw_format == XdwFormat.PDW_BASIC:
            b_pdw_payload = bitstring.pack('uint:4, uint:19, uint:25, int:64, uint:24',
                                           1, 0, t_on_ticks, i_freq_inc, 0)
        elif xdw_format == XdwFormat.PDW_EXPERT:
            b_pdw_payload = bitstring.pack('uint:4, uint:3, uint:25, int:64', 1, 0, t_on_ticks, i_freq_inc)
        else:
            raise ValueError('unsupported xdw format')

        return b_pdw_payload.bytes


@dataclass
class PdwPayloadRtChirpTriangular:
    """Payload class to generate triangular frequency modulated real-time pulse

    :param t_on: duration of pulse (on-time)
    :type t_on: float
    :param freq_step: frequency step per sample
    :type freq_step: float

    """
    t_on: float
    freq_step: float

    def get_payload(self, xdw_format: XdwFormat):
        """Assemble payload and return bytes object

        :param xdw_format: Type of xDW, e.g. PDW_BASIC
        :type xdw_format: XdwFormat
        :return: Raw payload
        :rtype: Bytes Object

        """
        t_on_ticks = int(self.t_on * 2.4e9)
        i_freq_inc = int(self.freq_step / 2.4e9 * (2 ** 64))

        assert t_on_ticks < (2**25), "t_on in ticks exceeds 25 bits"

        if xdw_format == XdwFormat.PDW_BASIC:
            t_on_ticks = t_on_ticks | (2 ** 45)  # set mod to 0x02
            b_pdw_payload = t_on_ticks.to_bytes(6, byteorder="big") + i_freq_inc.to_bytes(8, byteorder="big",
                                                                                          signed=True) + bytes(3)
        elif xdw_format == XdwFormat.PDW_EXPERT:
            t_on_ticks = t_on_ticks | (2 ** 29)  # set mod to 0x02
            b_pdw_payload = t_on_ticks.to_bytes(4, byteorder="big") + i_freq_inc.to_bytes(8, byteorder="big",
                                                                                          signed=True)
        else:
            raise ValueError('unsupported xdw format')

        return b_pdw_payload


@dataclass
class PdwPayloadRtBarker:
    """Payload class to generate Barker-coded real-time pulse

    :param chip_width: duration of single-chip, pulse width = Barker code length * chip_width
    :type chip_width: float
    :param code: type of Barker code
    :type code: int
    :param stuff: stuffing bits
    :type stuff: int, defaults to 0

    """
    chip_width: float
    code: int
    stuff: int = 0

    def get_payload(self, xdw_format: XdwFormat):
        """Assemble payload and return bytes object

        :param xdw_format: Type of xDW, e.g. PDW_BASIC
        :type xdw_format: XdwFormat
        :return: Raw payload
        :rtype: Bytes Object

        """
        assert 0 <= self.code <= 8, f'barker code {self.code} not supported.'
        assert self.stuff <= (2 ** 16 - 1), 'maximum value for STUFF is 65535'

        chip_width_ticks = int(self.chip_width * 2.4e9)

        assert chip_width_ticks < (2 ** 44), "chip_width in ticks exceeds 44 bits"

        if xdw_format == XdwFormat.PDW_BASIC:
            bs_packed = bitstring.pack('uint:4, uint:44, uint:4, uint:4, uint:16, uint:64',
                                       3, chip_width_ticks, self.code, 0, self.stuff, 0)
        elif xdw_format == XdwFormat.PDW_EXPERT:
            bs_packed = bitstring.pack('uint:4, uint:44, uint:4, uint:4, uint:16, uint:24',
                                       3, chip_width_ticks, self.code, 0, self.stuff, 0)
        else:
            raise ValueError('unsupported xdw format')

        return bs_packed.bytes
