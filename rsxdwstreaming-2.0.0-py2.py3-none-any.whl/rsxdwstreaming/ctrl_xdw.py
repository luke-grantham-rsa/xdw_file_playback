from abc import ABC
from enum import Enum

import bitstring
from .xdw_format import XdwFormat


class CtrlXdwCmd(Enum):
    """Enum for control descriptor word command type
    """
    FREQ = 0
    AMPL = 1
    FREQ_AMPL = 2
    ARM = 3
    EOF = 7


class CtrlXdw(ABC):
    """Base class for control descriptor words. Only to be used via classes Cdw, TcdwBasic or TcdwExpert.
    """
    # pylint: disable=too-many-instance-attributes
    def __init__(self, xdw_version, allowed_keys, **kwargs):
        self.toa = 0
        self.path = 0
        self.cmd = CtrlXdwCmd.FREQ

        self.fval = 0  # absolute instrument RF frequency (unsigned int)
        self.lval = 0  # absolute instrument RF level (signed fixed point)

        # all variables below shall be treated as private
        self.xdw_format = xdw_version
        self.b_xdw_header = b''
        self.b_xdw_body = b''

        for k, _ in kwargs.items():
            if k not in allowed_keys:
                assert False, f'{k} is not in {allowed_keys}'

        self.__dict__.update((k, v) for k, v in kwargs.items() if k in allowed_keys)

        # assert isinstance(self.cmd, CtrlXdwCmd), 'unsupported command, shall be of type CtrlXdwCmd'

    def create_xdw_header(self):
        """Assemble xCDW header and write to member variable
        """
        toa_ticks = round(self.toa * 2.4e9)

        if self.xdw_format == XdwFormat.PDW_BASIC:
            bs_packed = bitstring.pack('uint:44, uint:1, uint:3, uint:1, uint:15',
                                       toa_ticks, self.path, self.cmd.value, 1, 0)
        else:  # PDW_EXPERT and ADW_BASIC
            bs_packed = bitstring.pack('uint:52, uint:1, uint:3, uint:1, uint:7',
                                       toa_ticks, self.path, self.cmd.value, 1, 0)

        self.b_xdw_header = bs_packed.bytes

    def create_xdw_body(self):
        """Assemble xCDW body and write to member variable
        """
        lval = round(self.lval, 2)

        # lval calculation
        lval_sign = 0 if lval >= 0 else 1

        # doing string conversion, otherwise float resolution brings issues (5.34 -> 5.339999999...)
        lval_str = f'{abs(lval):.2f}'.split('.')

        lval_int = int(lval_str[0])
        lval_dec_1 = int(lval_str[1][0])
        lval_dec_0_1 = int(lval_str[1][1])

        lval_packed = bitstring.pack('uint:1, uint:7, uint:4, uint:4, uint:8',
                                     lval_sign, lval_int, lval_dec_1, lval_dec_0_1, 0)

        bs_packed = bitstring.pack('uint:40',
                                   self.fval)

        self.b_xdw_body = bs_packed.bytes + lval_packed.bytes

    def get_xdw(self):
        """Assemble xCDW from header and body

        :return: Raw expert PDW
        :rtype: Bytes Object

        """
        self.create_xdw_body()
        self.create_xdw_header()

        return self.b_xdw_header + self.b_xdw_body


class TcdwBasic(CtrlXdw):
    r"""Basic timed control descriptor word (TCDW) class

    :keyword toa: time-of-arrival (toa) describes the time of execution relative to simulation start
    :keyword path: Select instrument RF path, 0 = Path A, 1 = Path B
    :keyword fval: Instrument RF frequency value
    :keyword lval: Instrument RF level value
    :keyword cmd: Command type

    """
    def __init__(self, **kwargs):
        super().__init__(xdw_version=XdwFormat.PDW_BASIC, allowed_keys={'toa', 'path', 'fval', 'lval', 'cmd'}, **kwargs)


class TcdwExpert(CtrlXdw):
    r"""Expert timed control descriptor word (TCDW) class

    :keyword toa: time-of-arrival (toa) describes the time of execution relative to simulation start
    :keyword path: Select instrument RF path, 0 = Path A, 1 = Path B
    :keyword fval: Instrument RF frequency value
    :keyword lval: Instrument RF level value
    :keyword cmd: Command type

    """
    def __init__(self, **kwargs):
        super().__init__(xdw_version=XdwFormat.PDW_EXPERT, allowed_keys={'toa', 'path', 'fval', 'lval', 'cmd'}, **kwargs)


class Cdw(CtrlXdw):
    r"""Control descriptor word (CDW) class

    :keyword path: Select instrument RF path, 0 = Path A, 1 = Path B
    :keyword fval: Instrument RF frequency value
    :keyword lval: Instrument RF level value
    :keyword cmd: Command type

    """
    def __init__(self, **kwargs):
        super().__init__(xdw_version=XdwFormat.ADW_BASIC, allowedd_keys={'path', 'fval', 'lval', 'cmd'}, **kwargs)
