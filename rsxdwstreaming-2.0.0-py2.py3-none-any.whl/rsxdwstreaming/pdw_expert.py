import bitstring

from .xdw import Xdw
from .xdw_extension import PdwParamsStuffing, PdwParamsEdge, XdwExtensionUnused
from .xdw_format import XdwFormat


class PdwExpert(Xdw):
    r"""Expert pulse descriptor word (PDW) class

    :param payload: PDW payload
    :keyword toa: time-of-arrival (toa) describes the time of playback relative to simulation start
    :keyword ignore_xdw: Flag to determine if PDW is ignored
    :keyword phase_mod: Flag to set phase mode to absolute (=0) or relative (=1)
    :keyword m1: Marker 1
    :keyword m2: Marker 2
    :keyword m3: Marker 3
    :keyword freq_offset: Frequency offset in Hertz
    :keyword level_offset: Level offset in dB
    :keyword phase_offset: Phase offset in degree
    :keyword param: PDW parameters, defaults to PdwParamStuffing
    :keyword extension1: Extension 1, defaults to XdwExtensionUnused
    :keyword extension2: Extension 2, defaults to XdwExtensionUnused
    :keyword extension3: Extension 3, defaults to XdwExtensionUnused

    """
    def __init__(self, payload,
                 param=PdwParamsStuffing(),
                 extension1=XdwExtensionUnused(),
                 extension2=XdwExtensionUnused(),
                 extension3=XdwExtensionUnused(),
                 **kwargs):
        # pylint: disable=too-many-arguments
        super().__init__(xdw_format=XdwFormat.PDW_EXPERT, payload=payload, **kwargs)

        self.use_extension = 0
        self.params = 0

        self.param = param
        self.extensions = [extension1, extension2, extension3]

    def create_xdw_header(self):
        """Assemble expert PDW header and write to member variable
        """
        toa_ticks = round(self.toa * 2.4e9)

        bs_packed = bitstring.pack('uint:52, uint:1, uint:1, uint:2',
                                   toa_ticks, self.seg, self.use_extension, self.params)
        self.b_xdw_header = bs_packed.bytes

    def create_xdw_extension(self):
        """Assemble expert PDW extensions and return bytes object

        :return: Raw ADW extension
        :rtype: Bytes Object

        """
        bs_packed = bitstring.pack('uint:3, uint:3, uint:3, uint:7, bits:48, bits:48, bits:48',
                                   self.extensions[0].type, self.extensions[1].type, self.extensions[2].type, 0,
                                   self.extensions[0].extension, self.extensions[1].extension, self.extensions[2].extension)
        return bs_packed.bytes

    def get_xdw(self):
        """Assemble expert PDW from header, flags, body, params, payload and extensions

        :return: Raw expert PDW
        :rtype: Bytes Object

        """
        self.create_xdw_payload()  # create payload first as this function sets data used by flags and header

        self.create_xdw_flags()
        self.create_xdw_body()

        # check if an extension is defined
        for extension in self.extensions:
            if extension.__class__ is not XdwExtensionUnused:
                self.use_extension = 1
                self.params = 0

        if self.use_extension:
            b_xdw_extension = self.create_xdw_extension()
        else:
            if self.param.__class__ is PdwParamsEdge:
                self.params = 1
            b_xdw_param = self.param.param.bytes

        self.create_xdw_header()  # create header at last because seg, ext and param information is set not set before

        ret = self.b_xdw_header + self.b_xdw_flags + self.b_xdw_body

        if self.use_extension:
            ret = ret + self.b_xdw_payload + b_xdw_extension
        else:
            ret = ret + b_xdw_param + self.b_xdw_payload

        return ret
